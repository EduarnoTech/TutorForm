const express = require("express");
const router = express.Router();
const multer = require("multer");

const upload = require("../middleware/filesave");
const upload2 = require("../middleware/filesave2");

const { client_req, liveSessionReq, signUp,signIn ,history,liveHistory,profile,profile1,checkPassword,getPhone,refMaterial} = require("../controllers/client");

router.route("/C1").post(upload.array("quesFile"), client_req);
router.route("/refMaterial").post(upload2.array("refMaterial"), refMaterial);
router.route("/C2").post(upload.array("refMaterial"), liveSessionReq);
router.route("/history").post(history);
router.route("/liveHistory").post(liveHistory);
router.route("/signUp").post(signUp);
router.route("/signIn").post(signIn);
router.route("/profile").post(profile);
router.route("/profile1").post(profile1);
router.route("/getPhone").post(getPhone);

router.route("/checkPassword").post(checkPassword);

// router.route("/C1").post(client_req);

module.exports = router;
